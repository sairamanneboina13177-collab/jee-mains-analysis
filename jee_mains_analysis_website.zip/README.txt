JEE Mains Analysis — public static website

CONTENTS
- index.html: complete responsive website.

PUBLISH FREE WITH GITHUB PAGES
1. Sign in to https://github.com/ and create a new public repository, e.g. jee-mains-analysis.
2. Upload index.html to the repository root and commit the file.
3. Open repository Settings -> Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait for GitHub Pages to publish. Your public URL will look like:
   https://YOUR-USERNAME.github.io/jee-mains-analysis/

IMPORTANT
- This is a static public website. No login is required for visitors.
- The included paper records are clearly labelled demo/illustrative. Replace them with verified data before presenting them as actual JEE paper analysis.
- Records added in the browser are saved in that visitor's own browser only (localStorage); they are not shared with other visitors. To make a shared database/admin system, connect a backend such as Supabase or Firebase.
- The website uses no external library dependencies.
